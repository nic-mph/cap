//This code creates local storage keys called username and password 
var usernameLS = localStorage.getItem('username');
var passwordLS = localStorage.getItem('password');
console.log('JS file is connected')
//Creates a function to save new account information
function save_account(){  

//Capture values from inputs (username, password, confirm password) and save each in a variable.
var usernameI = document.getElementById('uname');
var passwordI = document.getElementById('pswrd');
var cPasswordI = document.getElementById('confirmpass');

// Check if user password and user confirm password match. IF they do match save in local storage, ELSE clear the input and tell the user to try again. Fill in the if statement below.
  if(passwordI.value == cPasswordI.value ){

    //Save user username to localStorage key username
    localStorage.setItem("username", usernameI.value);
    //Save user password to localStorage key password  
    localStorage.setItem("password", passwordI.value);
    //Let user know account has been created. 
    window.alert('Your account has been created');
    //This code sends user back to login page called index.html
    window.location.href = 'index.html';
  }else{

    //This code lets user know passwords do not match and user must try again
    window.alert('Your passwords did not match, try again!')

    // clear current Values
    passwordI.value = "";
    cPasswordI.value = "";
  } 
}

//This function will check if the login data matches the data stored in localStorage. 
function checkLogin(){
  //Capture values from inputs (username, password) and save each in a variable. 
    var loginUsername = document.getElementById('username-field');
    var loginPassword = document.getElementById('password-field');
    console.log(loginUsername.value);
    console.log(usernameLS);
    console.log(passwordLS);


  //IF statement that tells if user input matches data stored in localStorage keys username and password, send the user to the next page, ELSE alert the user they need to try again.
  console.log(loginUsername.value)
  console.log(loginPassword.value)
  if (loginUsername.value == usernameLS && loginPassword.value == passwordLS){
    console.log('true');

    window.location.assign('dashboard.html'); 
  } else{
    //--> Alert user to try again
    window.alert('Try Again');
    loginUsername.value = "";
    loginPassword.value = "";
  }
}

console.log('JS file is connected')
// THIS IS WHERE DASHBOARD STARTS
